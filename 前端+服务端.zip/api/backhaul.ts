import request from '@/utils/request'

export function backhaulLists(params?: any) {
    return request.get({ url: '/backhaul.backhaul/lists', params })
}

//支付上报

export function Paybackhaul(params?: any) {
    return request.get({ url: '/backhaul.backhaul/pay', params })
}

//表单上报

export function Formbackhaul(params?: any) {
    return request.get({ url: '/backhaul.backhaul/forms', params })
}

//查询详情
export function refundLog(params?: any) {
    return request.get({ url: '/backhaul.backhaul/info', params })
}

// 添加回传
export function caAdd(params: any) {
    return request.post({ url: '/backhaul.backhaul/caadd', params })
}

// 编辑回传
export function caEdit(params: any) {
    return request.post({ url: '/backhaul.backhaul/caedit', params })
}
// 回传详情
export function caDetail(params: any) {
    return request.get({ url: '/backhaul.backhaul/cadetail', params })
}

export function caLists(params?: any) {
    return request.get({ url: '/backhaul.backhaul/calists', params })
}
//回传s
export function hcLists(params?: any) {
    return request.get({ url: '/backhaul.hcdata/lists', params })
}

export function getCount(params: any) {
    return request.get({ url: '/backhaul.hcdata/getcount', params })
}

//
export function hcDelete(params: any) {
    return request.post({ url: '/backhaul.hcdata/hcdelete', params })
}


export function access(params: any) {
    return request.get({ url: '/backhaul.hcdata/access', params })
}
//访问城市

export function DqLists(params: any) {
    return request.get({ url: '/backhaul.backhaul/dqtlists', params })
}
 
export function TiLists(params: any) {
    return request.get({ url: '/backhaul.backhaul/tiLists', params })
}
export function FWList(params: any) {
    return request.get({ url: '/backhaul.backhaul/fWList', params })
}
 

export function hctLists(params?: any) {
    return request.get({ url: '/backhaul.backhaul/hctLists', params })
}
 

export function hcCount(params: any) {
    return request.get({ url: '/backhaul.hcdata/hccount', params })
}