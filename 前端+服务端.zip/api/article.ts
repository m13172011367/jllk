import request from '@/utils/request'

// 文章分类列表
export function articleCateLists(params?: any) {
    return request.get({ url: '/article.articleCate/lists', params })
}
// 查询渠道列表
export function articleCateAll(params?: any) {
    return request.post({ url: '/article.articleCate/all', params })
}

// 添加文章分类
export function articleCateAdd(params: any) {
    return request.post({ url: '/article.articleCate/add', params })
}

// 编辑文章分类
export function articleCateEdit(params: any) {
    return request.post({ url: '/article.articleCate/edit', params })
}

// 删除文章分类
export function articleCateDelete(params: any) {
    return request.post({ url: '/article.articleCate/delete', params })
}

// 文章分类详情
export function articleCateDetail(params: any) {
    return request.get({ url: '/article.articleCate/detail', params })
}

// 文章分类状态
export function articleCateStatus(params: any) {
    return request.post({ url: '/article.articleCate/updateStatus', params })
}

// 文章列表
export function articleLists(params?: any) {
    return request.get({ url: '/article.article/lists', params })
}
// 文章列表
export function articleAll(params?: any) {
    return request.get({ url: '/article/all', params })
}

// 添加文章
export function articleAdd(params: any) {
    return request.post({ url: '/article.article/add', params })
}

// 编辑文章
export function articleEdit(params: any) {
    return request.post({ url: '/article.article/edit', params })
}

// 删除文章
export function articleDelete(params: any) {
    return request.post({ url: '/article.article/delete', params })
}

// 文章详情
export function articleDetail(params: any) {
    return request.get({ url: '/article.article/detail', params })
}

// 文章分类状态
export function articleStatus(params: any) {
    return request.post({ url: '/article.article/updateStatus', params })
}
// 获取文章列表
export function backhaul(params?: any) {
    return request.get({ url: '/article.article/backhaul', params })
}


export function article_group(params?: any) {
    return request.get({ url: '/article.article/article_group', params })
}

// 复制出数据
export function articleCopy(params: any) {
    return request.post({ url: '/article.article/article_copy', params })
}

//套餐信息
export function PayPackage(params?: any) {
    return request.post({ url: '/article.articleCate/payPackage', params })
}
//套餐开通
export function PayPinfo(params: any) {
    return request.post({ url: '/article.articleCate/payPinfo', params })
}

//套餐列表
export function PayList(params: any) {
    return request.get({ url: '/article.articleCate/paylist', params })
}
 

export function PayEdit(params: any) {
    return request.post({ url: '/article.articleCate/payedit', params })
}

export function PayDetail(params: any) {
    return request.get({ url: '/article.articleCate/paydetail', params })
}