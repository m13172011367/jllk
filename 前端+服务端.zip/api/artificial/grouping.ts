import request from '@/utils/request'

// 列表
export function deptLists(params?: any) {
    return request.get({ url: '/artificial.grouping/lists', params })
}

// 添加
export function deptAdd(params: any) {
    return request.post({ url: '/artificial.grouping/add', params })
}

// 编辑部门
export function deptEdit(params: any) {
    return request.post({ url: '/artificial.grouping/edit', params })
}

// 删除部门
export function deptDelete(params: any) {
    return request.post({ url: '/artificial.grouping/delete', params })
}

// 详情
export function deptDetail(params: any) {
    return request.get({ url: '/artificial.grouping/detail', params })
}

// 查询分组
export function deptAll(params: any) {
    return request.get({ url: '/artificial.grouping/all', params })
}
//查询企业
export function enterpriseAll(params: any) {
    return request.get({ url: '/artificial.grouping/enterprise', params })
}
//查询子链接
export function customerAll(params: any) {
    return request.get({ url: '/artificial.grouping/customer', params })
}

//添加客服链接
export function customerAdd(params: any) {
    return request.post({ url: '/artificial.customer/add', params })
}
//列表
export function customerLists(params: any) {
    return request.get({ url: '/artificial.customer/lists', params })
}
//客服信息查询
export function customerDetail(params: any) {
    return request.get({ url: '/artificial.customer/detail', params })
}
//客服修改
export function customerEdit(params: any) {
    return request.post({ url: '/artificial.customer/edit', params })
}
//删除客服
export function customerDelete(params: any) {
    return request.post({ url: '/artificial.customer/delete', params })
}

export function chanStatus(params: any) {
    return request.post({ url: '/artificial.customer/updateStatus', params })
}