import request from '@/utils/request'

// 企业微信列表
export function apiWorkListsLists(params: any) {
    return request.get({ url: '/work.work_lists/lists', params })
}

// 添加企业微信
export function apiWorkListsAdd(params: any) {
    return request.post({ url: '/work.work_lists/add', params })
}

// 编辑企业微信
export function apiWorkListsEdit(params: any) {
    return request.post({ url: '/work.work_lists/edit', params })
}

// 删除企业微信
export function apiWorkListsDelete(params: any) {
    return request.post({ url: '/work.work_lists/delete', params })
}

// 企业微信详情
export function apiWorkListsDetail(params: any) {
    return request.get({ url: '/work.work_lists/detail', params })
}