import request from '@/utils/request'

// 添加记录列表
export function apiWorkCustomerAcquisitionLogLists(params: any) {
    return request.get({ url: '/work.work_customer_acquisition_log/lists', params })
}

// 添加添加记录
export function apiWorkCustomerAcquisitionLogAdd(params: any) {
    return request.post({ url: '/work.work_customer_acquisition_log/add', params })
}

// 编辑添加记录
export function apiWorkCustomerAcquisitionLogEdit(params: any) {
    return request.post({ url: '/work.work_customer_acquisition_log/edit', params })
}

// 删除添加记录
export function apiWorkCustomerAcquisitionLogDelete(params: any) {
    return request.post({ url: '/work.work_customer_acquisition_log/delete', params })
}

// 添加记录详情
export function apiWorkCustomerAcquisitionLogDetail(params: any) {
    return request.get({ url: '/work.work_customer_acquisition_log/detail', params })
}

export function getCount(params: any) {
    return request.get({ url: '/work.work_customer_acquisition_log/getCount', params })
}