import request from '@/utils/request'

// 企业微信列表
export function apiInfoLists(params: any) {
    return request.get({ url: '/work.info/lists', params })
}

// 添加企业微信
export function apiInfoAdd(params: any) {
    return request.post({ url: '/work.info/add', params })
}

// 编辑企业微信
export function apiInfoEdit(params: any) {
    return request.post({ url: '/work.info/edit', params })
}

// 删除企业微信
export function apiInfoDelete(params: any) {
    return request.post({ url: '/work.info/delete', params })
}

// 企业微信详情
export function apiInfoDetail(params: any) {
    return request.get({ url: '/work.info/detail', params })
}