import request from '@/utils/request'

// 渠道链接列表
export function apiWorkLinkChannelLists(params: any) {
    return request.get({ url: '/work.work_link_channel/lists', params })
}

// 添加渠道链接
export function apiWorkLinkChannelAdd(params: any) {
    return request.post({ url: '/work.work_link_channel/add', params })
}

// 编辑渠道链接
export function apiWorkLinkChannelEdit(params: any) {
    return request.post({ url: '/work.work_link_channel/edit', params })
}

// 删除渠道链接
export function apiWorkLinkChannelDelete(params: any) {
    return request.post({ url: '/work.work_link_channel/delete', params })
}

// 渠道链接详情
export function apiWorkLinkChannelDetail(params: any) {
    return request.get({ url: '/work.work_link_channel/detail', params })
}