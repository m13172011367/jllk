import request from '@/utils/request'

// 渠道链接列表
export function apiWorkLinkChannelCountLists(params: any) {
    return request.get({ url: '/work.work_link_channel_count/lists', params })
}
