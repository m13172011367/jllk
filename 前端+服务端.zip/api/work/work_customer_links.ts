import request from '@/utils/request'

// 拓客链接列表
export function apiWorkCustomerLinksLists(params: any) {
    return request.get({ url: '/work.work_customer_links/lists', params })
}

// 添加拓客链接
export function apiWorkCustomerLinksAdd(params: any) {
    return request.post({ url: '/work.work_customer_links/add', params })
}

// 编辑拓客链接
export function apiWorkCustomerLinksEdit(params: any) {
    return request.post({ url: '/work.work_customer_links/edit', params })
}

// 删除拓客链接
export function apiWorkCustomerLinksDelete(params: any) {
    return request.post({ url: '/work.work_customer_links/delete', params })
}

// 拓客链接详情
export function apiWorkCustomerLinksDetail(params: any) {
    return request.get({ url: '/work.work_customer_links/detail', params })
}